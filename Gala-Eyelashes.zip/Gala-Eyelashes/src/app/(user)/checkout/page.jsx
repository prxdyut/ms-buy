import { Checkout } from "@src/features/checkout";

import React from "react";

const CheckoutPage = () => {
  return <Checkout />;
};

export default CheckoutPage;
